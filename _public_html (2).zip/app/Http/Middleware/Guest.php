<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Guest
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // dd(Auth::user()->role);
        if (Auth::check() && ( Auth::user()->role_id == 1 || Auth::user()->role_id == 4)) { 
             return $next($request);
            //return redirect()->route('dashboard')->withSuccess(__('login successfully'));
        }
        
           return redirect()->route('admin.user.login')->withError(__('Admin unauthorized ,Please try again'));
    }
}
