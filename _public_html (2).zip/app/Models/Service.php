<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    use HasFactory;

    protected $table = 'services';

    protected $fillable = [
        'title',
        'price',
        'price_label',
        'features',
        'button_text',
        'status',
        'image'
    ];

    protected $casts = [
        'features' => 'array',
    ];
}
