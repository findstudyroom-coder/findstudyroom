<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    
    protected $table = 'bookings';
    protected $fillable = [
        'library_id',
        'name',
        'phone',
        'date'
    ];

    public function library()
    {
        return $this->belongsTo(Library::class);
    }
}